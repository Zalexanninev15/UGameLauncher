<?php
namespace ugl\forms;

use std, gui, framework, ugl;


class MainForm extends AbstractForm
{

    /**
     * @event button.action 
     */
    function doButtonAction(UXEvent $e = null)
    {    
        
    }

    /**
     * @event imageAlt.construct 
     */
    function doImageAltConstruct(UXEvent $e = null)
    {    
        
    }

    /**
     * @event image.construct 
     */
    function doImageConstruct(UXEvent $e = null)
    {    
        
    }

    /**
     * @event label.construct 
     */
    function doLabelConstruct(UXEvent $e = null)
    {    
        
    }

    /**
     * @event buttonAlt.action 
     */
    function doButtonAltAction(UXEvent $e = null)
    {    
        
    }

    /**
     * @event button3.action 
     */
    function doButton3Action(UXEvent $e = null)
    {    
        
    }

    /**
     * @event button4.action 
     */
    function doButton4Action(UXEvent $e = null)
    {    
        
    }

    /**
     * @event button6.action 
     */
    function doButton6Action(UXEvent $e = null)
    {    
        
    }

    /**
     * @event button5.action 
     */
    function doButton5Action(UXEvent $e = null)
    {    
        
    }

    /**
     * @event button10.action 
     */
    function doButton10Action(UXEvent $e = null)
    {    
        
    }

    /**
     * @event button9.action 
     */
    function doButton9Action(UXEvent $e = null)
    {    
        
    }

    /**
     * @event button11.action 
     */
    function doButton11Action(UXEvent $e = null)
    {    
        
    }

    /**
     * @event button6.mouseDown-Left 
     */
    function doButton6MouseDownLeft(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event button6.keyDown-Shift+F1 
     */
    function doButton6KeyDownShiftF1(UXKeyEvent $e = null)
    {    
        
    }

    /**
     * @event button8.action 
     */
    function doButton8Action(UXEvent $e = null)
    {    
        execute("cmd /c start start.bat");
    }

    /**
     * @event button7.action 
     */
    function doButton7Action(UXEvent $e = null)
    {    
        
    }





}
