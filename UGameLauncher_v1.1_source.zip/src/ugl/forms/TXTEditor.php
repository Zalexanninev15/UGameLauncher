<?php
namespace ugl\forms;

use std, gui, framework, ugl;        
use php\io\Stream;
use php\io\IOException;


class TXTEditor extends AbstractForm
{

    /**
     * @event textArea.construct 
     */
    function doTextAreaConstruct(UXEvent $e = null)
    {    
        
    }

    /**
     * @event button.action 
     */
    function doButtonAction(UXEvent $e = null)
    {    

try {
   Stream::putContents("./index/about.txt", $this->textArea->text);
} catch (IOException $e) {
   alert('Ошибка записи: ' . $e->getMessage());
}
    }

    /**
     * @event buttonAlt.action 
     */
    function doButtonAltAction(UXEvent $e = null)
    {
        
  }
  }
