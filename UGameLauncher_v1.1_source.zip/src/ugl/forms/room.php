<?php
namespace ugl\forms;

use std, gui, framework, ugl;


class room extends AbstractForm
{

    /**
     * @event image3.construct 
     */
    function doImage3Construct(UXEvent $e = null)
    {    
        
    }

    /**
     * @event imageAlt.construct 
     */
    function doImageAltConstruct(UXEvent $e = null)
    {    
        
    }

    /**
     * @event button.action 
     */
    function doButtonAction(UXEvent $e = null)
    {    
        
    }

    /**
     * @event buttonAlt.action 
     */
    function doButtonAltAction(UXEvent $e = null)
    {    
        
    }

    /**
     * @event rhombus.mouseDown-Left 
     */
    function doRhombusMouseDownLeft(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event circle.click-Left 
     */
    function doCircleClickLeft(UXMouseEvent $e = null)
    {    
        
    }

}
