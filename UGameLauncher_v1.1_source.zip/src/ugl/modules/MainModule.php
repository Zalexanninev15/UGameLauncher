<?php
namespace ugl\modules;

use std, gui, framework, ugl;


class MainModule extends AbstractModule
{


}
