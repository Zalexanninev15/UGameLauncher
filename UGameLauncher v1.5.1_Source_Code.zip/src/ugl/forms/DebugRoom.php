<?php
namespace ugl\forms;

use std, gui, framework, ugl;
use action\Element; 
use php\io\Stream; 


class DebugRoom extends AbstractForm
{


    /**
     * @event show 
     */
    function doShow(UXWindowEvent $e = null)
    {    
        //Проверка на настройки, если их нет то выставляем по умолчанию
        $iniPath = getcwd()."\\config.ini";
        if( !file_exists($iniPath) )
        {
            $this->ini->set('name','texmod');
            $this->ini->set('format','exe');
            $this->nameED->text = "texmod";
            $this->formatED->text = "exe";
        }
        else //Если настройки уже есть, загружаем их в поля
        {
            //Здесь загрузка настроек в поля:
            $this->nameED->text = $this->ini->get('name');
            $this->formatED->text = $this->ini->get('format');
        }
        
        
        
    }

    /**
     * @event executeBTN.click-Left 
     */
    function doExecuteBTNClickLeft(UXMouseEvent $e = null)
    {    
        $progPath = getcwd();   //Директория нашей проги
        $name = $this->ini->get('name');   //Название проги которую надо запустить 
        $format = $this->ini->get('format');   //Расширение проги которую надо запустить
        
        $execPath = $progPath."\\index\\soft\\favorite\\$name.$format";   //Итоговый путь к проге
        
        if( file_exists($execPath) )   //Если программа существует
        {
            execute($execPath, false);   //Запуск программы по пути
        }
        else   //Ели не существует
        {
            $this->toast('Программа не найдена');  //Уведомляем
        }
        
        
    }

    /**
     * @event renameBTN.click-Left 
     */
    function doRenameBTNClickLeft(UXMouseEvent $e = null)
    {    
        if( $this->nameED->text != "" and $this->formatED->text != "" )   //Если поля не пусты сохраняем настройки
        {
            $this->ini->set('name',$this->nameED->text);  
            $this->ini->set('format',$this->formatED->text);
            $this->toast('Переименовано');
        }
        else    //Если поля пусты, просим не оставлять их пустыми и возрашаем настройки в поля
        {
            $this->toast("Не оставляйте поля пустыми");
            $this->nameED->text = $this->ini->get('name');
            $this->formatED->text = $this->ini->get('format');
        }
    }

    /**
     * @event image.construct 
     */
    function doImageConstruct(UXEvent $e = null)
    {    
        Element::loadContentAsync($e->sender, './index/data/poster.jpg', function () use ($e, $event) {
        });
    }

    /**
     * @event imageAlt.construct 
     */
    function doImageAltConstruct(UXEvent $e = null)
    {    
        Element::loadContentAsync($e->sender, './index/data/background.jpg', function () use ($e, $event) {
        });
    }

    /**
     * @event buttonAlt.action 
     */
    function doButtonAltAction(UXEvent $e = null)
    {
        Element::loadContentAsync($e->imageAlt, './index/data/background.jpg', function () use ($e, $event) {
        });
    }

    /**
     * @event button.action 
     */
    function doButtonAction(UXEvent $e = null)
    {    
        Element::loadContentAsync($e->image, './index/data/poster.jpg', function () use ($e, $event) {
        });
    }



}
