<?php
namespace ugl\forms;

use php\io\IOException;
use std, gui, framework, ugl;
use action\Element; 
use php\io\Stream; 


class Set1 extends AbstractForm
{


    /**
     * @event button4.action 
     */
    function doButton4Action(UXEvent $e = null)
    {
         Element::loadContentAsync($this->textArea, './index/data/about.txt', function () use ($e, $event) {
        });
         $this->button9->hide();
         $this->button8->hide();
         $this->textArea->show();
         $this->image->hide();
         $this->button7->hide();
         $this->label->hide();
         $this->button->hide();
         $this->button10->show();
         $this->button11->show(); 
    }

    /**
     * @event button5.action 
     */
    function doButton5Action(UXEvent $e = null)
    {
        Element::loadContentAsync($this->textArea, 'game.bat', function () use ($e, $event) {
        });
        $this->button9->show();
        $this->button8->show();
        $this->textArea->show();
        $this->image->hide();
        $this->button7->hide();
        $this->label->hide();
        $this->button->hide();
        $this->button10->hide();
        $this->button11->hide();  
    }

    /**
     * @event buttonAlt.action 
     */
    function doButtonAltAction(UXEvent $e = null)
    {
         $this->button9->hide();
         $this->button8->hide();
         $this->textArea->hide();
         $this->image->show();
         $this->button7->show();
         $this->label->show();
         $this->button->show();
         $this->button10->hide();
         $this->button11->hide();  
    }

    /**
     * @event button10.action 
     */
    function doButton10Action(UXEvent $e = null)
    {
         Element::loadContentAsync($this->textArea, './index/data/about.txt', function () use ($e, $event) {
        });
    }

    /**
     * @event button11.action 
     */
    function doButton11Action(UXEvent $e = null)
    {
                try {
           Stream::putContents("./index/data/about.txt", $this->textArea->text);
        } catch (IOException $e) {
           alert('Ошибка записи: ' . $e->getMessage());
        }
    }

    /**
     * @event textArea.construct 
     */
    function doTextAreaConstruct(UXEvent $e = null)
    {    
        
    }

    /**
     * @event button.action 
     */
    function doButtonAction(UXEvent $e = null)
    {
        browse('https://zalexanninev15.jimdofree.com/');
    }

    /**
     * @event button7.action 
     */
    function doButton7Action(UXEvent $e = null)
    {
        browse('https://zalexanninev15.jimdofree.com/поддержка/');
    }


    /**
     * @event button9.action 
     */
    function doButton9Action(UXEvent $e = null)
    {    
        Element::loadContentAsync($this->textArea, 'game.bat', function () use ($e, $event) {
        });
    }

    /**
     * @event button8.action 
     */
    function doButton8Action(UXEvent $e = null)
    {
                try {
           Stream::putContents("game.bat", $this->textArea->text);
        } catch (IOException $e) {
           alert('Ошибка записи: ' . $e->getMessage());
        }
    }

    /**
     * @event image.click-Left 
     */
    function doImageClickLeft(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event image.mouseDown-Left 
     */
    function doImageMouseDownLeft(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event image.globalKeyPress-Alt+F9 
     */
    function doImageGlobalKeyPressAltF9(UXKeyEvent $e = null)
    {    
        
    }

    /**
     * @event button3.action 
     */
    function doButton3Action(UXEvent $e = null)
    {
        app()->hideForm($this->getContextFormName());
    }



}
