<?php
namespace ugl\forms;

use std, gui, framework, ugl;
use action\Element; 
use php\io\Stream; 
use php\gui\UXDialog; 
use action\Media; 


class Launcher extends AbstractForm
{


    /**
     * @event image.construct 
     */
    function doImageConstruct(UXEvent $e = null)
    {
        Element::loadContentAsync($e->sender, './index/data/poster.jpg', function () use ($e, $event) {
        });
    }

    /**
     * @event button5.action 
     */
    function doButton5Action(UXEvent $e = null)
    {
         app()->showForm('Set1');
    }

    /**
     * @event label.construct 
     */
    function doLabelConstruct(UXEvent $e = null)
    {
        Element::loadContentAsync($e->sender, './index/data/about.txt', function () use ($e, $event) {
        });
    }

    /**
     * @event button3.action 
     */
    function doButton3Action(UXEvent $e = null)
    {
        
        
        // Generated
        $e = $event ?: $e; // legacy code from 16 rc-2
        
        open('./index/data/interesting.url');
    }


    /**
     * @event imageAlt.construct 
     */
    function doImageAltConstruct(UXEvent $e = null)
    {
        Element::loadContentAsync($e->sender, './index/data/background.jpg', function () use ($e, $event) {
            Media::open('./index/data/music.mp3', true, $this->player);
        });
    }

    /**
     * @event button8.action 
     */
    function doButton8Action(UXEvent $e = null)
    {
        execute("cmd /c start game.bat");
    }






    /**
     * @event button4.action 
     */
    function doButton4Action(UXEvent $e = null)
    {
        app()->showForm('DebugRoom');
    }

/**
     * @event show 
     */
    function doShow(UXWindowEvent $e = null)
    {    
        //Проверка на настройки, если их нет то выставляем по умолчанию
        $iniPath = getcwd()."\\config.ini";
        if( !file_exists($iniPath) )
        {
            $this->ini->set('name','pak');
            $this->ini->set('format','exe');
            $this->nameED->text = "pak";
            $this->formatED->text = "exe";
        }
        else //Если настройки уже есть, загружаем их в поля
        {
            //Здесь загрузка настроек в поля:
            $this->nameED->text = $this->ini->get('name');
            $this->formatED->text = $this->ini->get('format');
        }
        
        
        
    }


    /**
     * @event renameBTN.click-Left 
     */
    function doRenameBTNClickLeft(UXMouseEvent $e = null)
    {    
        if( $this->nameED->text != "" and $this->formatED->text != "" )   //Если поля не пусты сохраняем настройки
        {
            $this->ini->set('name',$this->nameED->text);  
            $this->ini->set('format',$this->formatED->text);
            $this->toast('Переименовано');
        }
        else    //Если поля пусты, просим не оставлять их пустыми и возрашаем настройки в поля
        {
            $this->toast("Не оставляйте поля пустыми");
            $this->nameED->text = $this->ini->get('name');
            $this->formatED->text = $this->ini->get('format');
        }
    }


    /**
     * @event executeBTN.action 
     */
    function doExecuteBTNAction(UXEvent $e = null)
    {
        $progPath = getcwd();   //Директория нашей проги
        $name = $this->ini->get('name');   //Название проги которую надо запустить 
        $format = $this->ini->get('format');   //Расширение проги которую надо запустить
        
        $execPath = $progPath."\\index\\soft\\favorite\\$name.$format";   //Итоговый путь к проге
        
        if( file_exists($execPath) )   //Если программа существует
        {
            execute($execPath, false);   //Запуск программы по пути
        }
        else   //Ели не существует
        {
            $this->toast('Программа не найдена');  //Уведомляем
        }
        
        
    }

    /**
     * @event executeBTN.construct 
     */
    function doExecuteBTNConstruct(UXEvent $e = null)
    {    
        Element::loadContentAsync($e->sender, './index/soft/favorite/name.txt', function () use ($e, $event) {
        });
    }


    /**
     * @event buttonAlt.action 
     */
    function doButtonAltAction(UXEvent $e = null)
    {
        app()->shutdown();
    }



}
