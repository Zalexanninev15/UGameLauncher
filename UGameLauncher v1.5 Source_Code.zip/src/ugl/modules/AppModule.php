<?php
namespace ugl\modules;

use std, gui, framework, ugl;


class AppModule extends AbstractModule
{

}